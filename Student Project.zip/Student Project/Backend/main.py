from flask import Flask
from flask_cors import CORS
import psycopg2
from app.controllers.student_controller import student_bp
from app.config import get_db_config

app = Flask(__name__)
CORS(app)

# Register blueprints
app.register_blueprint(student_bp)

if __name__ == '__main__':
    # Create table if it doesn't exist
    conn = psycopg2.connect(**get_db_config())
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS public.student (
            id SERIAL PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            dob DATE NOT NULL,
            address VARCHAR(200) NOT NULL,
            gender VARCHAR(10) NOT NULL,
            department VARCHAR(50) NOT NULL,
            cutoff_mark FLOAT NOT NULL,
            phone_no VARCHAR(15) NOT NULL,
            email VARCHAR(120) UNIQUE NOT NULL
        );
    """)
    conn.commit()
    cur.close()
    conn.close()
    
    app.run(debug=True)
