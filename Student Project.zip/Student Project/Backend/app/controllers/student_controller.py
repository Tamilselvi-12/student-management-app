from flask import Blueprint, request, jsonify
from ..services import student_service

student_bp = Blueprint('student', __name__)

def format_student(student):
    return {
        'id': student[0],
        'name': student[1],
        'dob': student[2].strftime('%Y-%m-%d'),
        'address': student[3],
        'gender': student[4],
        'department': student[5],
        'cutoff_mark': float(student[6]),
        'phone_no': student[7],
        'email': student[8]
    }

@student_bp.route('/students', methods=['POST'])
def create_student():
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        student = student_service.create_student(data)
        return jsonify({
            'message': 'Student created successfully',
            'student': format_student(student)
        }), 201
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@student_bp.route('/students', methods=['GET'])
def get_all_students():
    try:
        students = student_service.get_all_students()
        return jsonify([format_student(student) for student in students]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@student_bp.route('/students/<int:student_id>', methods=['GET'])
def get_student(student_id):
    try:
        student = student_service.get_student_by_id(student_id)
        return jsonify(format_student(student)), 200
    except ValueError as e:
        return jsonify({'error': str(e)}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@student_bp.route('/students/<int:student_id>', methods=['PUT'])
def update_student(student_id):
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        student = student_service.update_student(student_id, data)
        return jsonify({
            'message': 'Student updated successfully',
            'student': format_student(student)
        }), 200
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@student_bp.route('/students/<int:student_id>', methods=['DELETE'])
def delete_student(student_id):
    try:
        student_service.delete_student(student_id)
        return jsonify({'message': 'Student deleted successfully'}), 200
    except ValueError as e:
        return jsonify({'error': str(e)}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500 