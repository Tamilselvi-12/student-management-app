from ..repositories import student_repository
import re
from email_validator import validate_email, EmailNotValidError

def validate_phone(phone):
    pattern = re.compile(r'^\+?1?\d{9,15}$')
    return bool(pattern.match(phone))

def validate_student_data(data):
    if not data.get('name') or not data.get('dob') or not data.get('address'):
        raise ValueError("Name, DOB, and address are required")
    
    if not validate_phone(data.get('phone_no', '')):
        raise ValueError("Invalid phone number")
    
    try:
        validate_email(data.get('email', ''))
    except EmailNotValidError:
        raise ValueError("Invalid email address")

def create_student(student_data):
    validate_student_data(student_data)
    return student_repository.create_student(student_data)

def get_all_students():
    return student_repository.get_all_students()

def get_student_by_id(student_id):
    student = student_repository.get_student_by_id(student_id)
    if not student:
        raise ValueError("Student not found")
    return student

def update_student(student_id, update_data):
    if update_data.get('phone_no') and not validate_phone(update_data['phone_no']):
        raise ValueError("Invalid phone number")
    
    if update_data.get('email'):
        try:
            validate_email(update_data['email'])
        except EmailNotValidError:
            raise ValueError("Invalid email address")

    student = student_repository.update_student(student_id, update_data)
    if not student:
        raise ValueError("Student not found")
    return student

def delete_student(student_id):
    result = student_repository.delete_student(student_id)
    if not result:
        raise ValueError("Student not found")
    return result 