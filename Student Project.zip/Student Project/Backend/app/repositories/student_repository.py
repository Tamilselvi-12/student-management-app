import psycopg2
from datetime import datetime
from ..config import get_db_config

def get_connection():
    return psycopg2.connect(**get_db_config())

def create_student(student_data):
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO public.student (name, dob, address, gender, department, cutoff_mark, phone_no, email)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING *;
            """, (
                student_data['name'],
                datetime.strptime(student_data['dob'], '%Y-%m-%d').date(),
                student_data['address'],
                student_data['gender'].lower(),
                student_data['department'],
                float(student_data['cutoff_mark']),
                student_data['phone_no'],
                student_data['email']
            ))
            return cur.fetchone()

def get_all_students():
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM public.student")
            return cur.fetchall()

def get_student_by_id(student_id):
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM public.student WHERE id = %s", (student_id,))
            return cur.fetchone()

def update_student(student_id, update_data):
    with get_connection() as conn:
        with conn.cursor() as cur:
            update_fields = []
            values = []
            for key, value in update_data.items():
                if key == 'dob':
                    value = datetime.strptime(value, '%Y-%m-%d').date()
                elif key == 'cutoff_mark':
                    value = float(value)
                elif key == 'gender':
                    value = value.lower()
                update_fields.append(f"{key} = %s")
                values.append(value)
            
            values.append(student_id)
            update_query = f"""
                UPDATE public.student 
                SET {', '.join(update_fields)}
                WHERE id = %s
                RETURNING *;
            """
            cur.execute(update_query, values)
            return cur.fetchone()

def delete_student(student_id):
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM public.student WHERE id = %s RETURNING id", (student_id,))
            return cur.fetchone() 