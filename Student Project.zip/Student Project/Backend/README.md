# Student Management API

This is a Flask-based REST API for managing student information. The API allows you to perform CRUD (Create, Read, Update, Delete) operations on student records.

## Setup

1. Install the required dependencies:
```bash
pip install -r requirements.txt
```

2. Run the application:
```bash
python main.py
```

The server will start on `http://localhost:5000`

## API Endpoints

### 1. Create a New Student
- **URL:** `/students`
- **Method:** `POST`
- **Data Format:**
```json
{
    "name": "John Doe",
    "dob": "2000-01-01",
    "address": "123 Main St, City",
    "gender": "male",
    "department": "Computer Science",
    "cutoff_mark": 85.5,
    "phone_no": "+1234567890",
    "email": "john@example.com"
}
```

### 2. Get All Students
- **URL:** `/students`
- **Method:** `GET`

### 3. Get Student by ID
- **URL:** `/students/<student_id>`
- **Method:** `GET`

### 4. Update Student
- **URL:** `/students/<student_id>`
- **Method:** `PUT`
- **Data Format:** (Include only fields to be updated)
```json
{
    "name": "John Smith",
    "email": "john.smith@example.com"
}
```

### 5. Delete Student
- **URL:** `/students/<student_id>`
- **Method:** `DELETE`

## Data Validation
- Email must be valid
- Phone number must be between 9-15 digits
- Gender must be one of: male, female, other
- All fields are required when creating a new student
- Date of birth must be in YYYY-MM-DD format
- Cutoff mark must be a valid number 