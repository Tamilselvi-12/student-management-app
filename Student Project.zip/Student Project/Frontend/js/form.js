let currentAction = 'new';
let studentId = '';

// Initialize form based on URL parameters
document.addEventListener('DOMContentLoaded', async () => {
    const params = new URLSearchParams(window.location.search);
    currentAction = params.get('action') || 'new';
    studentId = params.get('id') || '';

    updateFormTitle();

    if (currentAction === 'view' || currentAction === 'edit') {
        await loadStudentData();
    }

    if (currentAction === 'view') {
        makeFormReadOnly();
    }
});

function updateFormTitle() {
    const titles = {
        'new': 'Add New Student',
        'edit': 'Edit Student',
        'view': 'View Student Details'
    };
    document.getElementById('formTitle').textContent = titles[currentAction];

    if (currentAction === 'view') {
        document.getElementById('submitBtn').style.display = 'none';
    }
}

async function loadStudentData() {
    try {
        const response = await fetch(`http://localhost:5000/students/${studentId}`);
        if (!response.ok) throw new Error('Failed to fetch student data');

        const student = await response.json();
        populateForm(student);
    } catch (error) {
        console.error('Error:', error);
        alert('Failed to load student data');
        navigateToGrid();
    }
}

function populateForm(student) {
    const form = document.getElementById('studentForm');
    for (const [key, value] of Object.entries(student)) {
        const input = form.elements[key];
        if (input) {
            if (key === 'dob') {
                input.value = new Date(value).toISOString().split('T')[0];
            } else {
                input.value = value;
            }
        }
    }
}

function makeFormReadOnly() {
    const form = document.getElementById('studentForm');
    Array.from(form.elements).forEach(element => {
        element.readOnly = true;
        if (element.tagName === 'SELECT') {
            element.disabled = true;
        }
        element.classList.add('readonly-view');
    });
}

function validateForm(formData) {
    let isValid = true;
    const errors = {};

    // Clear previous errors
    document.querySelectorAll('.error-message').forEach(el => {
        el.style.display = 'none';
        el.textContent = '';
    });

    // Required fields validation
    ['name', 'dob', 'address', 'gender', 'department', 'cutoff_mark', 'phone_no', 'email'].forEach(field => {
        if (!formData.get(field)) {
            errors[field] = 'This field is required';
            isValid = false;
        }
    });

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (formData.get('email') && !emailRegex.test(formData.get('email'))) {
        errors.email = 'Invalid email address';
        isValid = false;
    }

    // Phone number validation
    const phoneRegex = /^\+?\d{9,15}$/;
    if (formData.get('phone_no') && !phoneRegex.test(formData.get('phone_no'))) {
        errors.phone_no = 'Invalid phone number format. Must be 9-15 digits with optional + prefix';
        isValid = false;
    }

    // Cutoff mark validation
    const cutoffMark = parseFloat(formData.get('cutoff_mark'));
    if (isNaN(cutoffMark) || cutoffMark < 0 || cutoffMark > 100) {
        errors.cutoff_mark = 'Cutoff mark must be between 0 and 100';
        isValid = false;
    }

    // Date validation
    const dob = new Date(formData.get('dob'));
    if (dob > new Date()) {
        errors.dob = 'Date of birth cannot be in the future';
        isValid = false;
    }

    // Length validations
    if (formData.get('name').length > 100) {
        errors.name = 'Name must be less than 100 characters';
        isValid = false;
    }
    if (formData.get('address').length > 200) {
        errors.address = 'Address must be less than 200 characters';
        isValid = false;
    }
    if (formData.get('department').length > 50) {
        errors.department = 'Department must be less than 50 characters';
        isValid = false;
    }

    // Display errors if any
    Object.keys(errors).forEach(field => {
        const errorElement = document.getElementById(`${field}Error`);
        if (errorElement) {
            errorElement.textContent = errors[field];
            errorElement.style.display = 'block';
        }
    });

    return isValid;
}

// Modify the navigation function to check if we're in the middle of saving
let isSaving = false;

function navigateToGrid() {
    // If we're in the middle of saving, don't show the warning
    if (isSaving) {
        window.location.href = 'Grid.html';
        return;
    }

    Swal.fire({
        title: 'Are you sure?',
        text: "Any unsaved changes will be lost!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#764ba2',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Yes, leave page'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'Grid.html';
        }
    });
}

document.getElementById('studentForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = new FormData(e.target);

    if (!validateForm(formData)) {
        return;
    }

    const studentData = Object.fromEntries(formData.entries());

    try {
        console.log(currentAction);

        const url = currentAction === 'new'
            ? 'http://localhost:5000/students'
            : `http://localhost:5000/students/${studentId}`;

        const method = currentAction === 'new' ? 'POST' : 'PUT';

        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(studentData)
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'Failed to save student data');
        }

        // After successful save, navigate directly to grid without showing alerts
        window.location.href = 'Grid.html';
    } catch (error) {
        console.error('Error:', error);
        alert(error.message);
    }
});

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('studentForm');
    const progressBar = document.querySelector('.progress-bar');
    const completionPercentage = document.getElementById('completionPercentage');
    const addressTextarea = document.getElementById('address');
    const addressCharCount = document.getElementById('addressCharCount');
    
    // Initialize form validation
    const fields = form.querySelectorAll('input, select, textarea');
    
    // Update form completion progress
    function updateProgress() {
        const totalFields = fields.length;
        let filledFields = 0;
        
        fields.forEach(field => {
            if (field.value.trim() !== '') {
                filledFields++;
            }
        });
        
        const percentage = Math.round((filledFields / totalFields) * 100);
        progressBar.style.width = `${percentage}%`;
        progressBar.setAttribute('aria-valuenow', percentage);
        completionPercentage.textContent = percentage;
        
        // Update progress bar color based on completion
        if (percentage < 33) {
            progressBar.className = 'progress-bar bg-danger';
        } else if (percentage < 66) {
            progressBar.className = 'progress-bar bg-warning';
        } else {
            progressBar.className = 'progress-bar bg-success';
        }
    }
    
    // Add input event listeners for real-time validation and progress update
    fields.forEach(field => {
        field.addEventListener('input', function() {
            validateField(this);
            updateProgress();
        });
        
        field.addEventListener('blur', function() {
            validateField(this);
        });
    });
    
    // Character counter for address
    addressTextarea.addEventListener('input', function() {
        const remaining = this.value.length;
        addressCharCount.textContent = remaining;
        
        if (remaining >= 180) {
            addressCharCount.style.color = '#dc3545';
        } else if (remaining >= 150) {
            addressCharCount.style.color = '#ffc107';
        } else {
            addressCharCount.style.color = '';
        }
    });
    
    // Field validation function
    function validateField(field) {
        const errorDiv = document.getElementById(`${field.id}Error`);
        let isValid = true;
        let errorMessage = '';
        
        // Remove existing validation classes
        field.classList.remove('is-valid', 'is-invalid');
        
        // Check if field is required and empty
        if (field.required && field.value.trim() === '') {
            isValid = false;
            errorMessage = 'This field is required';
        } else {
            // Specific validation rules
            switch(field.id) {
                case 'name':
                    if (field.value.length < 2) {
                        isValid = false;
                        errorMessage = 'Name must be at least 2 characters long';
                    }
                    break;
                    
                case 'email':
                    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                    if (!emailRegex.test(field.value)) {
                        isValid = false;
                        errorMessage = 'Please enter a valid email address';
                    }
                    break;
                    
                case 'phone_no':
                    const phoneRegex = /^\+?\d{9,15}$/;
                    if (!phoneRegex.test(field.value)) {
                        isValid = false;
                        errorMessage = 'Please enter a valid phone number';
                    }
                    break;
                    
                case 'cutoff_mark':
                    const mark = parseFloat(field.value);
                    if (isNaN(mark) || mark < 0 || mark > 100) {
                        isValid = false;
                        errorMessage = 'Mark must be between 0 and 100';
                    }
                    break;
                    
                case 'dob':
                    const date = new Date(field.value);
                    const today = new Date();
                    const age = today.getFullYear() - date.getFullYear();
                    if (age < 15 || age > 100) {
                        isValid = false;
                        errorMessage = 'Please enter a valid date of birth';
                    }
                    break;
            }
        }
        
        // Update validation UI
        if (field.value.trim() !== '') {
            field.classList.add(isValid ? 'is-valid' : 'is-invalid');
        }
        
        // Show/hide error message with animation
        if (errorMessage) {
            errorDiv.textContent = errorMessage;
            errorDiv.classList.add('show');
        } else {
            errorDiv.classList.remove('show');
        }
        
        return isValid;
    }
    
    // Form submission
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        let isValid = true;
        fields.forEach(field => {
            if (!validateField(field)) {
                isValid = false;
            }
        });
        
        if (isValid) {
            const submitBtn = document.getElementById('submitBtn');
            submitBtn.classList.add('loading');
            submitBtn.disabled = true;
            
            // Simulate form submission (replace with actual API call)
            setTimeout(() => {
                submitBtn.classList.remove('loading');
                submitBtn.disabled = false;
                
                // Show success message
                Swal.fire({
                    title: 'Success!',
                    text: 'Student information has been submitted successfully.',
                    icon: 'success',
                    confirmButtonColor: '#764ba2'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Redirect or reset form as needed
                        form.reset();
                        updateProgress();
                        fields.forEach(field => {
                            field.classList.remove('is-valid', 'is-invalid');
                        });
                    }
                });
            }, 1500);
        } else {
            // Show error message for invalid form
            Swal.fire({
                title: 'Error!',
                text: 'Please fill in all required fields correctly.',
                icon: 'error',
                confirmButtonColor: '#764ba2'
            });
            
            // Scroll to first error
            const firstError = form.querySelector('.is-invalid');
            if (firstError) {
                firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }
    });
    
    // Add hover effect to form
    const studentForm = document.querySelector('.student-form');
    studentForm.addEventListener('mousemove', function(e) {
        const rect = this.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        this.style.setProperty('--x', `${x}px`);
        this.style.setProperty('--y', `${y}px`);
    });
});