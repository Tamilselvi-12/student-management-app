// Function to load students data
async function loadStudents() {
    try {
        const response = await fetch('http://localhost:5000/students');
        console.log(response);

        if (!response.ok) {
            throw new Error('Failed to fetch students');
        }
        const students = await response.json();
        displayStudents(students);
    } catch (error) {
        console.error('Error:', error);
        alert('Failed to load students data');
    }
}

// Function to display students in the table
function displayStudents(students) {
    const tableBody = document.getElementById('studentTableBody');
    tableBody.innerHTML = '';

    if (!students || students.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td colspan="10" class="text-center">No records found</td>
        `;
        tableBody.appendChild(row);
        return;
    }

    students.forEach(student => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><a class="student-id-link" onclick="navigateToForm('view', '${student.id}')">${student.id}</a></td>
            <td>${student.name}</td>
            <td>${new Date(student.dob).toLocaleDateString()}</td>
            <td>${student.address}</td>
            <td>${student.gender}</td>
            <td>${student.department}</td>
            <td>${student.cutoff_mark}</td>
            <td>${student.phone_no}</td>
            <td>${student.email}</td>
            <td class="action-buttons">
                <button class="btn btn-sm btn-primary" onclick="navigateToForm('edit', '${student.id}')">Edit</button>
                <button class="btn btn-sm btn-danger" onclick="deleteStudent('${student.id}')">Delete</button>
            </td>
        `;
        tableBody.appendChild(row);
    });
}

// Function to delete a student
async function deleteStudent(id) {
    if (!confirm('Are you sure you want to delete this student?')) {
        return;
    }

    try {
        const response = await fetch(`http://localhost:5000/students/${id}`, {
            method: 'DELETE'
        });

        if (response.status === 200) {
            loadStudents(); // Refresh the grid
        } else {
            throw new Error('Failed to delete student');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Failed to delete student');
    }
}

// Function to navigate to form
function navigateToForm(action, id = '') {
    const queryParams = new URLSearchParams();
    queryParams.append('action', action);
    if (id) {
        queryParams.append('id', id);
    }
    window.location.href = `form.html?${queryParams.toString()}`;
}

// Load students when page loads
document.addEventListener('DOMContentLoaded', loadStudents);